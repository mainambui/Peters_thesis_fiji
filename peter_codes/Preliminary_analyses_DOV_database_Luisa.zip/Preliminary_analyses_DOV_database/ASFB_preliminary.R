#Prelimnary analyses for ASFB conference 2016
#

#Data available
#4 locations, 8 sites with 2 fish transects (50x5m) = total of 16 transects 

#Edgelists - Add nodes characteristics:

#Databases required:
#1. PropFinalNodes.csv 
#2. MQRF_Samples_Lat_Lon
#3. resid15Edge.rds
#4. gensites_bioIDs.csv - database already merged (grids ID with Genetic samples locations)


#load library 
library(here)
library(dplyr)
library(tidyverse)
library(RColorBrewer)
library(hutilscpp) 
library(tidyverse)
library(viridis)
library(patchwork)
library(hrbrthemes)
library(circlize)
library(chorddiag)  #devtools::install_github("mattflor/chorddiag")
library(igraph)
library(reshape2)
library(rfishbase)


#Load database with node properties - add Countries using nodesSOV database
nodesFinal<- read.csv(here("PropFinalNodes.csv"))
#Remove irrelevant columns
nodesFinal <- nodesFinal[,3:14]
#Remove duplicates from previous merging 
length(unique(nodesFinal$ID)) #14804 (unique)
nodesFinal <-nodesFinal[!duplicated(nodesFinal), ]
#check 
dim(nodesFinal) # ok, matches the unique IDs

#Set Ocean Realms
nodesFinal$Ocean_realm <- ifelse(nodesFinal$Kulbicki == "Western Indian", "Western Indian",
                                 ifelse(nodesFinal$Kulbicki == "Central Indo_Pacific", "Pacific",
                                        ifelse(nodesFinal$Kulbicki == "Central Pacific", "Pacific",
                                               ifelse(nodesFinal$Kulbicki == "Tropical Eastern Pacific", "Pacific",
                                                      ifelse(nodesFinal$Kulbicki == "Western Atlantic", "Atlantic",
                                                             ifelse(nodesFinal$Kulbicki == "Easter Atlantic", "Atlantic", NA))))))


#read genetics sites coords
gensites<-read.csv("MQRF_Samples_Lat_Lon.csv")
head(gensites)


#Find the closest node ID for each 
head(gensites) 
head(nodesFinal)

#library(geosphere)
library(dplyr)
library(purrr)
library(sf)
library(geosphere)

# Function to find nearest ID and its coordinates for one site
find_nearest_node <- function(lat, lon, nodesFinal) {
  dists <- distHaversine(c(lon, lat), nodesFinal[, c("Lon", "Lat")])
  nearest_index <- which.min(dists)
  nodesFinal[nearest_index, ]
}

# Apply the function to each row of gensites
nearest_matches <- pmap_dfr(
  list(gensites$lat, gensites$lon),
  ~ find_nearest_node(..1, ..2, nodesFinal)
)

# Bind new columns to gensites
gensites <- gensites %>%
  bind_cols(
    closest_ID = nearest_matches$ID,
    closest_Lat = nearest_matches$Lat,
    closest_Lon = nearest_matches$Lon
  )

#write.csv(gensites, "MQRFsites_bioIDs.csv")
MQRFsites <- read.csv("MQRFsites_bioIDs.csv")

DOV_sites<-MQRFsites[MQRFsites$data_type %in% "DOV",]
head(DOV_sites)

#Retrive Opcode based on sites 
Metadata<-read.csv("DOV_Metadata_Transects.csv")

DOVMetadata <- DOV_sites %>%
  left_join(Metadata %>% dplyr::select(Site,Geomoprh,OpCode), by = c('site' = 'Site'))
#remove potential duplicates
DOVMetadata <-DOVMetadata[!duplicated(DOVMetadata), ]
DOVMetadata <-DOVMetadata[!duplicated(DOVMetadata$X), ]
#identical(unique(DOVMetadata$site),unique(DOV_sites$site))

#Extract gravity values nodes file
DOVMetadata <- DOVMetadata %>%
  left_join(nodesFinal %>% dplyr::select(ID,Grav_tot), by = c('closest_ID' = 'ID'))

#Extract connectivity values from global matrix

conmetrics <- read.csv("global_connectivity.csv")
dim(conmetrics)

DOVMetadata <- DOVMetadata %>%
  left_join(conmetrics, by = c('closest_ID' = 'ID'))

#NodesProperti Fiji
#FijiNodes<-nodesFinal[nodesFinal$TERRITORY1=="Fiji",]
#write.csv(FijiNodes, "FijiNodesCon.csv")


#2. Calculate Biomass and Abundance 

#1st step combine all event measure datasets using bind

LEnghtKAD_CAT <- read.csv(here("Preliminary Results", "KAD_CAT_3D point and length measurements.csv"))
LEnghtKAD_COW <- read.csv(here("Preliminary Results", "KAD_COW_3D point and length measurements.csv"))
LEnghtKAD_SO1 <- read.csv(here("Preliminary Results", "KAD_SO1_3D point and length measurements.csv"))
LEnghtKUA_FRO <- read.csv(here("Preliminary Results", "KUA_MPA_2_3D point and length measurements.csv"))
LEnghtSAV_SLR <- read.csv(here("Preliminary Results", "SAV_SLR_3D point and length measurements.csv"))
LEnghtWAI_MYS <- read.csv(here("Preliminary Results", "WAI_MYS_3D point and length measurements.csv"))
LEnghtYA_COW <- read.csv(here("Preliminary Results", "YA_COW_3D point and length measurements.csv"))
LEnghtVAN_DAL <- read.csv(here("Preliminary Results", "VAN_DAL_3D point and length measurements.csv"))
LEnghtVAN_DAL <- read.csv(here("Preliminary Results", "VAN_DAL_3D point and length measurements.csv"))


#EMobs combined for 3d measurements and lenghts

EmobsCombined<- big_dataset <- bind_rows(LEnghtKAD_CAT, LEnghtKAD_COW, LEnghtKAD_SO1,
                                         LEnghtKUA_FRO,LEnghtSAV_SLR,LEnghtWAI_MYS,LEnghtYA_COW,
                                         LEnghtVAN_DAL)

View(EmobsCombined)

EmobsCombined$Species<-ifelse(EmobsCombined$Species == "","sp", EmobsCombined$Species)

#Remove rows with no Fish ID (should not occur after analyses are finalised)
EmobsCombined <- EmobsCombined[!EmobsCombined$Genus == "",]
unique(EmobsCombined$Genus) #ok 

#Create column with Genus_species 
EmobsCombined<-EmobsCombined %>%
mutate(Species_full =paste(Genus, Species, sep="_")) 
head(EmobsCombined)

#Fishbase a and b parameters

# Get unique species from your dataset
species_list <- unique(EmobsCombined$Species_full)
head(species_list)

# Query FishBase for length-weight parameters
length_weight_data <- length_weight(species_list)

length_weight_summary <- length_weight_data %>%
  group_by(Species) %>%
  summarise(a = mean(a, na.rm = TRUE),
            b = mean(b, na.rm = TRUE))

#EmobsCombined <- EmobsCombined %>%
#  left_join(length_weight_summary, by = c("Species_full"="Species"))

unique_species_sp <- EmobsCombined %>%
  filter(grepl("sp", Species_full, ignore.case = TRUE)) %>%
  distinct(Species_full)

unique_species_sp <- unique_species_sp[!unique_species_sp %in% "Scarus spinus",]

unique_species_sp <- as.data.frame(unique_species_sp)
colnames(unique_species_sp)[1] <- "Species_full"


unique_species_sp<- unique_species_sp %>%
  mutate(Genus = word(Species_full, 1))


library(dplyr)
library(stringr)

genus_lookup <- length_weight_summary %>%
  mutate(Genus = word(Species, 1)) %>%
  group_by(Genus) %>%
  slice(1) %>%
  ungroup() %>%
  select(Genus, a, b)

genus_only_filled <- unique_species_sp %>%
  left_join(genus_lookup, by = "Genus")


#compleate manually the ones missing:
genus_only_filled$a <- ifelse(genus_only_filled$Genus == "Myripristis", "0.02089",
                              ifelse(genus_only_filled$Genus == "Ctenochaetus", "0.03388",
                                    ifelse(genus_only_filled$Genus == "Centropyge", "0.03090",
                                           ifelse(genus_only_filled$Genus == "Pseudanthias", "0.01122",
                                                  ifelse(genus_only_filled$Genus == "Neoglyphidodon", "0.01905",
                                                         ifelse(genus_only_filled$Genus == "Amphiprion","0.01479",genus_only_filled$a))))))
                       
genus_only_filled$b <- ifelse(genus_only_filled$Genus == "Myripristis", "3.03",
                              ifelse(genus_only_filled$Genus == "Ctenochaetus", "2.93",
                                     ifelse(genus_only_filled$Genus == "Centropyge", "2.88",
                                            ifelse(genus_only_filled$Genus == "Pseudanthias", "3.04",
                                                   ifelse(genus_only_filled$Genus == "Neoglyphidodon", "2.99",
                                                          ifelse(genus_only_filled$Genus == "Amphiprion","3.00",genus_only_filled$b))))))

#Complete final dataset 
genus_only_filled <- genus_only_filled[,c("Species_full","a","b")]
colnames(genus_only_filled)[1] <- "Species"
genus_only_filled$a <- as.numeric(genus_only_filled$a)
genus_only_filled$b <- as.numeric(genus_only_filled$b)
length_weight_summary <- bind_rows(as.data.frame(length_weight_summary),genus_only_filled)

#add columns again a and b
EmobsCombined <- EmobsCombined %>%
  left_join(length_weight_summary, by = c("Species_full"="Species"))

#Filter RMS
EmobsCombined <- EmobsCombined[EmobsCombined$RMS..mm.<20,]

#2nd step - Calculate Biomass
#Transform 


#calculate biomass
EmobsCombined$biomass<- EmobsCombined$a * EmobsCombined$Length..mm.^EmobsCombined$b
EmobsCombined$biomass.g.<- EmobsCombined$biomass/100


EmobsMeanBio<-aggregate(biomass.g. ~ Period + OpCode, EmobsCombined,sum)
EmobsMeanBio<-aggregate(biomass.g. ~  OpCode, EmobsMeanBio,mean)

head(EmobsMeanBio)

#Sum of rowns by transect
EmobsAbun <- EmobsCombined %>%
  group_by(OpCode, Period) %>%
  summarise(n_individuals = n(), .groups = "drop")


#rought abundance - all fish counted - here use both length and point measurements 
EmobsAbun <- EmobsCombined %>%
  group_by(OpCode, Period) %>%
  summarise(n_individuals = n(), .groups = "drop")


PointKAD_CAT <- read.csv(here("Preliminary Results", "KAD_CAT_3D point and length measurements.csv"))
PointKAD_COW <- read.csv(here("Preliminary Results", "KAD_COW_3D point and length measurements.csv"))
PointKAD_SO1 <- read.csv(here("Preliminary Results", "KAD_SO1_3D point and length measurements.csv"))
PointKUA_FRO <- read.csv(here("Preliminary Results", "KUA_MPA_2_3D point and length measurements.csv"))
PointSAV_SLR <- read.csv(here("Preliminary Results", "SAV_SLR_3D point and length measurements.csv"))
PointWAI_MYS <- read.csv(here("Preliminary Results", "WAI_MYS_3D point and length measurements.csv"))
PointYA_COW <- read.csv(here("Preliminary Results", "YA_COW_3D point and length measurements.csv"))
PointVAN_DAL <- read.csv(here("Preliminary Results", "VAN_DAL_3D point and length measurements.csv"))


PointsCombined <- bind_rows(PointKAD_CAT, PointKAD_COW, PointKAD_SO1,
                                         PointKUA_FRO,PointSAV_SLR,PointWAI_MYS,PointYA_COW,
                                         PointVAN_DAL)

PointAbun <- PointsCombined  %>%
  group_by(OpCode, Period) %>%
  summarise(n_individuals = n(), .groups = "drop")

AbunCombined<- bind_rows(PointAbun,EmobsAbun)

EmobsMeanAbun<-aggregate(n_individuals ~ Period + OpCode, AbunCombined,sum)
EmobsMeanAbun<-aggregate(n_individuals ~  OpCode, EmobsMeanAbun,mean)

EmobsMeanBioAbun <- EmobsMeanBio %>%
  left_join(EmobsMeanAbun, by = "OpCode")




###Include explanatory variables

#Create a "adoption" category based on Jaganeesh et al map 2023).
EmobsMeanBioAbun$Adoption <- ifelse(EmobsMeanBioAbun$OpCode %in% c("YA_COW","VAN_DAL",
                                                                   "KUA_FRO"), "Non-Adopters","Adopters")


#Include connectivity and gravity variables
head(DOVMetadata)


EmobsPreAn<-EmobsMeanBioAbun %>% 
  left_join(DOVMetadata,by = "OpCode")

EmobsPreAn$logbiomass.g. <- log(EmobsPreAn$biomass.g.)
EmobsPreAn$loggrav. <- log(EmobsPreAn$Grav_tot)
EmobsPreAn$logcrypto5BRIF <- log(EmobsPreAn$crypto5BRIF)
EmobsPreAn$logcrypto5LR <- log1p(EmobsPreAn$crypto5LR)
EmobsPreAn$netflow<- (EmobsPreAn$crypto5BROF - EmobsPreAn$crypto5BRIF)/(EmobsPreAn$crypto5BROF + EmobsPreAn$crypto5BRIF)

head(EmobsPreAn)



library(lme4)
install.packages("visreg")
library(visreg)

# Example GLMM (Gaussian family, linear)
model1<-lm(logbiomass.g.~ loggrav.+ Adoption + logcrypto5LR, data=EmobsPreAn)
visreg::visreg(model1)

EmobsPreAn$site<-as.factor(EmobsPreAn$site)
EmobsPreAn$Adoption<-as.factor(EmobsPreAn$Adoption)

summary(model1)

# Summary of the model







